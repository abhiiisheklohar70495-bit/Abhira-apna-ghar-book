export function sanitize(input: string): string {
  return String(input ?? "")
    .replace(/[&<>"'`]/g, (s) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
      "`": "&#96;",
    }[s] as string));
}

# Razorpay & S3 Integration Notes

## Razorpay create order
- Use `/api/razorpay/create-order` to create server-side orders. Supply `amount` in rupees.
- On client, use Razorpay Checkout with the returned `order.id` (see Razorpay docs).
- After payment, Razorpay will call your webhook endpoint `/api/razorpay/webhook`. Configure `RAZORPAY_WEBHOOK_SECRET` in env and verify signature.

## S3 presigned upload
- Use `/api/upload-url` with JSON `{ filename, contentType }` and header `x-abhira-admin: <key>` to get a signed `PUT` URL and `key`.
- Client should `PUT` the file to the signed URL and then save the resulting `key` in the room `images` array (e.g., `https://{S3_BUCKET}.s3.{S3_REGION}.amazonaws.com/{key}` with appropriate ACL/permissions).

## Prisma & Postgres
- Schema in `prisma/schema.prisma`. After setting `DATABASE_URL`, run:
  - `npx prisma generate`
  - `npx prisma migrate dev --name init`
- Use a managed Postgres (Railway, Supabase, Heroku) in production.


'use client';
import React, { useState } from 'react';

export default function Page() {
  const [hostAadhar, setHostAadhar] = useState('');
  const [hostPhoto, setHostPhoto] = useState(null);
  const [hostSelfie, setHostSelfie] = useState(null);

  const handleCheckout = async () => {
    const res = await fetch('/api/razorpay/create-order', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({amount:29900}) });
    const data = await res.json();
    const options = {
      key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
      amount: data.amount,
      currency: data.currency,
      name: 'Abhira Apna Ghar Book',
      order_id: data.id,
      handler: function(response){
        alert('Payment successful! Razorpay Payment ID: ' + response.razorpay_payment_id);
      }
    };
    const rzp = new window.Razorpay(options);
    rzp.open();
  };

  return <div style={{padding:'20px'}}>
    <h1>Host Recharge & KYC</h1>
    <input placeholder="Aadhaar Number" value={hostAadhar} onChange={e=>setHostAadhar(e.target.value)} /><br/><br/>
    <input type="file" onChange={e=>setHostPhoto(e.target.files[0])} /><br/><br/>
    <input type="file" onChange={e=>setHostSelfie(e.target.files[0])} /><br/><br/>
    <button onClick={handleCheckout}>Pay ₹299 & Submit KYC</button>
    <hr/>
    <h2>Admin / Owner Dashboard</h2>
    <p>All payments, bookings, host/customer KYC info visible here.</p>
  </div>
}

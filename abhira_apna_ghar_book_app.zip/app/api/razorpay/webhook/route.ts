import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { prisma } from '@/lib/db';

// Razorpay webhook secret -> set RAZORPAY_WEBHOOK_SECRET in env
export async function POST(req: NextRequest) {
  const signature = req.headers.get('x-razorpay-signature') || '';
  const body = await req.text();
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET || '';
  const expected = crypto.createHmac('sha256', secret).update(body).digest('hex');
  if(!signature || expected !== signature){
    return NextResponse.json({ error: 'invalid signature' }, { status: 400 });
  }
  const payload = JSON.parse(body);
  // Example: payment.captured for an order -> mark booking as paid
  if(payload.event === 'payment.captured'){
    const orderId = payload.payload.payment.entity.order_id;
    // find booking with this orderId stored in metadata (implementation detail)
    // This starter doesn't store orderId yet; leave hook example for extension.
    // You can implement mapping when creating order by sending bookingId in notes.
    console.log('payment captured for order', orderId);
  }
  return NextResponse.json({ ok: true });
}

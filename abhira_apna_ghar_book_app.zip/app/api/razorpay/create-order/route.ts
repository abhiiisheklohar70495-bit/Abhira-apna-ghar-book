import { NextRequest, NextResponse } from 'next/server';
import Razorpay from 'razorpay';
import { z } from 'zod';

const Body = z.object({
  amount: z.number().int().min(1), // rupees
  currency: z.string().default('INR'),
  receipt: z.string().optional()
});

export async function POST(req: NextRequest) {
  const parsed = Body.safeParse(await req.json());
  if(!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const { amount, currency, receipt } = parsed.data;

  const razor = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID || '', key_secret: process.env.RAZORPAY_KEY_SECRET || '' });
  const order = await razor.orders.create({ amount: amount * 100, currency, receipt: receipt || `rcpt_${Date.now()}` });
  return NextResponse.json(order);
}

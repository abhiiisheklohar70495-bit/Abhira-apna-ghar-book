import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

const Input = z.object({
  filename: z.string().min(3),
  contentType: z.string().min(3)
});

export async function POST(req: NextRequest) {
  const apiKey = req.headers.get('x-abhira-admin');
  if(!apiKey || apiKey !== process.env.ABHIRA_ADMIN_KEY){
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const body = await req.json();
  const parsed = Input.safeParse(body);
  if(!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const { filename, contentType } = parsed.data;

  const bucket = process.env.S3_BUCKET;
  const region = process.env.S3_REGION;
  const client = new S3Client({
    region,
    credentials: { accessKeyId: process.env.S3_KEY || '', secretAccessKey: process.env.S3_SECRET || '' }
  });

  const key = `uploads/${Date.now()}-${filename}`;
  const command = new PutObjectCommand({ Bucket: bucket, Key: key, ContentType: contentType, ACL: 'private' });
  const url = await getSignedUrl(client, command, { expiresIn: 900 }); // 15 minutes
  return NextResponse.json({ url, key });
}

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/db';
import { sanitize } from '@/lib/sanitize';

const RoomInput = z.object({
  hostPhone: z.string().min(6),
  hostName: z.string().min(2),
  hostUPI: z.string().optional(),
  city: z.string().min(2),
  title: z.string().min(3),
  price: z.number().int().min(100),
  thali: z.boolean(),
  images: z.array(z.string()).optional(),
  notes: z.string().optional()
});

export async function GET() {
  const rooms = await prisma.room.findMany({ include: { host: true, bookings: true } });
  return NextResponse.json(rooms);
}

export async function POST(req: NextRequest) {
  const apiKey = req.headers.get('x-abhira-admin');
  if (!apiKey || apiKey !== process.env.ABHIRA_ADMIN_KEY) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const body = await req.json();
  const parsed = RoomInput.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const data = parsed.data;
  // upsert host
  const host = await prisma.host.upsert({
    where: { phone: data.hostPhone },
    update: { name: sanitize(data.hostName), upi: data.hostUPI ? sanitize(data.hostUPI) : undefined },
    create: { phone: data.hostPhone, name: sanitize(data.hostName), upi: data.hostUPI ? sanitize(data.hostUPI) : undefined },
  });
  const room = await prisma.room.create({
    data: {
      title: sanitize(data.title),
      city: sanitize(data.city),
      price: data.price,
      thali: data.thali,
      images: data.images || [],
      notes: data.notes ? sanitize(data.notes) : undefined,
      hostId: host.id
    }
  });
  return NextResponse.json(room, { status: 201 });
}

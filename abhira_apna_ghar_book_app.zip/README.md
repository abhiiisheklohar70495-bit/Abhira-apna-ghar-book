# Abhira — Production Starter

This starter includes:
- Next.js (App Router) frontend + backend API routes
- Prisma + PostgreSQL schema (Rooms, Bookings, Hosts, Payouts)
- Razorpay server integration (create order, verify payment webhook)
- AWS S3 presigned upload example for images
- Zod validation and input sanitization

## Quick Start (local)

1. Install
```bash
npm install
```

2. Set environment variables
```bash
cp .env.example .env
# Edit .env and set DATABASE_URL, ABHIRA_ADMIN_KEY, RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET, S3_*
```

3. Generate Prisma client & run migrations (creates initial schema)
```bash
npx prisma generate
npx prisma migrate dev --name init
```

4. Run dev
```bash
npm run dev
```

Open http://localhost:3000

## Endpoints (server)
- `GET /api/rooms` — list rooms
- `POST /api/rooms` — add room (requires `x-abhira-admin` header)
- `POST /api/upload-url` — get S3 presigned PUT URL for image upload (requires `x-abhira-admin` or host phone match)
- `POST /api/razorpay/create-order` — create Razorpay order (server-side)
- `POST /api/razorpay/webhook` — webhook endpoint; verifies signature and marks bookings paid

## Security notes
- Protect admin key and use proper auth (NextAuth or custom JWT) for hosts in production.
- Do not commit `.env` or secrets.
- Use HTTPS in production and enable HSTS.
